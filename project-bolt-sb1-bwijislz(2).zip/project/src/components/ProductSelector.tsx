import { useState, useEffect } from 'react';
import { X, ExternalLink, Loader } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { products } from '../data/products';

interface ProductSelectorProps {
  categoryId: string;
  categoryTitle: string;
  onClose: () => void;
}

export function ProductSelector({ categoryId, categoryTitle, onClose }: ProductSelectorProps) {
  const { language, t } = useLanguage();
  const [categoryProducts, setCategoryProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const filtered = products.filter(p => p.categoryId === categoryId);
    setCategoryProducts(filtered);
    setLoading(false);
  }, [categoryId]);

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleRedirect = () => {
    if (!selectedProduct) return;

    const message = t(
      'سيتم توجيهك الآن إلى موقع الشريك. شكرًا لاستخدامك رابطنا التابع!',
      'You will now be redirected to the partner site. Thank you for using our affiliate link!'
    );
    alert(message);
    window.open(selectedProduct.affiliateUrl, '_blank');
    onClose();
  };

  const handleBuyProduct = (product: Product) => {
    const message = t(
      'سيتم توجيهك الآن إلى موقع الشريك. شكرًا لاستخدامك رابطنا التابع!',
      'You will now be redirected to the partner site. Thank you for using our affiliate link!'
    );
    alert(message);
    window.open(product.affiliateUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-green-600 to-green-700 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">
              {t('اختر منتجك', 'Choose Your Product')}
            </h2>
            <p className="text-green-100 mt-1">{categoryTitle}</p>
          </div>
          <button
            onClick={onClose}
            className="hover:bg-white/20 p-2 rounded-lg transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader className="w-8 h-8 animate-spin text-green-600" />
            </div>
          ) : categoryProducts.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">
                {t('لا توجد منتجات متاحة حالياً', 'No products available at the moment')}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {categoryProducts.map((product) => (
                <div
                  key={product.id}
                  className={`p-4 border-2 rounded-lg transition ${
                    selectedProduct?.id === product.id
                      ? 'border-green-500 bg-green-50'
                      : 'border-gray-200 hover:border-green-300'
                  }`}
                >
                  <div onClick={() => handleSelectProduct(product)} className="cursor-pointer">
                    <img
                      src={product.imageUrl}
                      alt={language === 'ar' ? product.nameAr : product.nameEn}
                      className="w-full h-40 object-cover rounded-lg mb-3"
                    />
                    <h3 className="font-bold text-lg text-gray-800 mb-2">
                      {language === 'ar' ? product.nameAr : product.nameEn}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {language === 'ar' ? product.descriptionAr : product.descriptionEn}
                    </p>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-2xl font-bold text-green-600">
                        {product.price} {t('ريال', 'SAR')}
                      </span>
                      {selectedProduct?.id === product.id && (
                        <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                          ✓ {t('مختار', 'Selected')}
                        </span>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => handleBuyProduct(product)}
                    className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition flex items-center justify-center gap-2"
                  >
                    {t('اشتر الآن', 'Buy Now')}
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-4 mb-4">
            <button
              onClick={handleRedirect}
              disabled={!selectedProduct}
              className={`flex-1 font-bold py-3 px-6 rounded-lg transition flex items-center justify-center gap-2 ${
                selectedProduct
                  ? 'bg-green-500 hover:bg-green-600 text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              {t('انتقل للشراء', 'Go to Purchase')}
              <ExternalLink className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-6 rounded-lg transition"
            >
              {t('إغلاق', 'Close')}
            </button>
          </div>

          {selectedProduct && (
            <div className="bg-gradient-to-r from-green-50 to-green-100 border-2 border-green-400 rounded-lg p-5">
              <h4 className="font-bold text-green-900 mb-3 text-lg">
                {t('ملخص الشراء', 'Purchase Summary')}
              </h4>
              <div className="space-y-2 mb-4">
                <p className="text-gray-800">
                  <span className="font-semibold text-green-800">{t('المنتج:', 'Product:')} </span>
                  {language === 'ar' ? selectedProduct.nameAr : selectedProduct.nameEn}
                </p>
                <p className="text-gray-800">
                  <span className="font-semibold text-green-800">{t('الوصف:', 'Description:')} </span>
                  {language === 'ar' ? selectedProduct.descriptionAr : selectedProduct.descriptionEn}
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 border-2 border-green-300">
                <p className="text-center text-sm text-gray-600 mb-2">
                  {t('المبلغ المستحق للدفع:', 'Total Amount Due')}
                </p>
                <p className="text-center text-4xl font-bold text-green-600">
                  {selectedProduct.price}
                </p>
                <p className="text-center text-sm text-gray-600 mt-2 font-semibold">
                  {t('ريال سعودي', 'SAR')}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
