import { Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer id="contact" className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-6 relative pb-3">
              {t('عن الموقع', 'About Us')}
              <span className="absolute bottom-0 right-0 w-10 h-1 bg-green-500 rounded"></span>
            </h3>
            <p className="text-gray-300 mb-6 leading-relaxed">
              {t(
                'دليلك للتسوق هو موقع تسويق بالعمولة يقدم أفضل العروض والمنتجات من شركات موثوقة.',
                'Your Shopping Guide is an affiliate marketing site that offers the best deals and products from trusted companies.'
              )}
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-green-500 rounded-full flex items-center justify-center transition"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-green-500 rounded-full flex items-center justify-center transition"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-green-500 rounded-full flex items-center justify-center transition"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 hover:bg-green-500 rounded-full flex items-center justify-center transition"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 relative pb-3">
              {t('أقسام الموقع', 'Site Categories')}
              <span className="absolute bottom-0 right-0 w-10 h-1 bg-green-500 rounded"></span>
            </h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('ملابس', 'Clothes')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('أثاث', 'Furniture')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('أجهزة', 'Devices')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('عقارات', 'Real Estate')}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 relative pb-3">
              {t('معلومات مهمة', 'Important Information')}
              <span className="absolute bottom-0 right-0 w-10 h-1 bg-green-500 rounded"></span>
            </h3>
            <ul className="space-y-2">
              <li>
                <a href="#how-it-works" className="text-gray-300 hover:text-green-400 transition">
                  {t('كيف يعمل', 'How It Works')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('الأسئلة الشائعة', 'FAQ')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('سياسة الخصوصية', 'Privacy Policy')}
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-green-400 transition">
                  {t('شروط الاستخدام', 'Terms of Use')}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6 relative pb-3">
              {t('اتصل بنا', 'Contact Us')}
              <span className="absolute bottom-0 right-0 w-10 h-1 bg-green-500 rounded"></span>
            </h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-gray-300">
                <MapPin className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span>{t('الرياض، المملكة العربية السعودية', 'Riyadh, Saudi Arabia')}</span>
              </li>
              <li className="flex items-center gap-3 text-gray-300">
                <Phone className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span>+966 12 345 6789</span>
              </li>
              <li className="flex items-center gap-3 text-gray-300">
                <Mail className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span>info@dallek.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="bg-black/20 rounded-lg p-4 mb-6">
          <p className="text-sm text-gray-300 leading-relaxed">
            <strong>{t('إفصاح:', 'Disclosure:')}</strong>{' '}
            {t(
              'هذا الموقع يحتوي على روابط تابعة. هذا يعني أننا قد نكسب عمولة إذا قمت بالشراء من خلال هذه الروابط، دون أي تكلفة إضافية عليك. نحن نوصي فقط بالمنتجات والخدمات التي نعتقد أنها ستضيف قيمة لزوارنا.',
              'This site contains affiliate links. This means we may earn a commission if you make a purchase through these links, at no extra cost to you. We only recommend products and services that we believe will add value to our visitors.'
            )}
          </p>
        </div>

        <div className="text-center text-sm text-gray-400 pt-6 border-t border-gray-700">
          <p>
            {t(
              'جميع الحقوق محفوظة © 2023 دليلك للتسوق - موقع تسويق بالعمولة',
              'All Rights Reserved © 2023 Your Shopping Guide - Affiliate Marketing Site'
            )}
          </p>
        </div>
      </div>
    </footer>
  );
}
