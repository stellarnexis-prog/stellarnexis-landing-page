import { useState } from 'react';
import { Phone, Mail, MapPin, Gauge, Fuel, Cog, Bed, Bath, Square } from 'lucide-react';
import { RealEstateListing, CarListing } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { BuyerRegistrationForm } from './BuyerRegistrationForm';

interface ListingCardProps {
  listing: RealEstateListing | CarListing;
  type: 'real_estate' | 'car';
}

export function ListingCard({ listing, type }: ListingCardProps) {
  const { language, t } = useLanguage();
  const [showBuyerForm, setShowBuyerForm] = useState(false);
  const [registeredBuyer, setRegisteredBuyer] = useState<{
    name: string;
    email: string;
    phone: string;
  } | null>(null);

  const isCarListing = (l: any): l is CarListing => {
    return 'brand' in l && 'model' in l && 'year' in l;
  };

  const title = language === 'ar' ? listing.titleAr : listing.titleEn;
  const description = language === 'ar' ? listing.descriptionAr : listing.descriptionEn;

  const car = isCarListing(listing) ? listing : null;
  const property = !isCarListing(listing) ? (listing as RealEstateListing) : null;

  return (
    <>
      <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all">
        <div className="relative">
          {listing.imageUrls && listing.imageUrls.length > 0 && (
            <img
              src={listing.imageUrls[0]}
              alt={title}
              className="w-full h-64 object-cover"
            />
          )}
          {listing.commitmentSigned && (
            <div className="absolute top-3 right-3 bg-green-500 text-white px-3 py-1 rounded-full text-xs font-bold">
              ✓ {t('موثق', 'Verified')}
            </div>
          )}
        </div>

        <div className="p-6">
          <h3 className="text-2xl font-bold text-gray-800 mb-2">{title}</h3>

          <p className="text-gray-600 mb-4 line-clamp-2 leading-relaxed">{description}</p>

          {car ? (
            <div className="grid grid-cols-2 gap-3 mb-4 pb-4 border-b">
              <div className="flex items-center gap-2 text-gray-700">
                <span className="font-bold text-lg">{car.brand}</span>
                <span>{car.model}</span>
                <span className="text-sm text-gray-500">({car.year})</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Gauge className="w-4 h-4" />
                <span className="text-sm">{car.mileage.toLocaleString()} {t('كم', 'km')}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Fuel className="w-4 h-4" />
                <span className="text-sm">
                  {t(
                    car.fuelType === 'petrol'
                      ? 'بنزين'
                      : car.fuelType === 'diesel'
                        ? 'ديزل'
                        : car.fuelType === 'hybrid'
                          ? 'هجين'
                          : 'كهربائي',
                    car.fuelType
                  )}
                </span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Cog className="w-4 h-4" />
                <span className="text-sm">
                  {t(
                    car.transmission === 'manual' ? 'يدوي' : 'أوتوماتيك',
                    car.transmission
                  )}
                </span>
              </div>
            </div>
          ) : property ? (
            <div className="grid grid-cols-3 gap-3 mb-4 pb-4 border-b text-gray-600">
              <div className="flex items-center gap-2">
                <Bed className="w-4 h-4" />
                <span className="text-sm">{property.bedrooms} {t('غرفة', 'Beds')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Bath className="w-4 h-4" />
                <span className="text-sm">{property.bathrooms} {t('حمام', 'Baths')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Square className="w-4 h-4" />
                <span className="text-sm">{property.area} {t('م²', 'm²')}</span>
              </div>
            </div>
          ) : null}

          <div className="mb-4">
            <div className="text-3xl font-bold text-green-600 mb-2">
              {listing.price.toLocaleString()} {t('ريال', 'SAR')}
            </div>
            <p className="text-sm text-gray-500">
              {t('المكتب: 1%', 'Commission: 1%')}
            </p>
          </div>

          <button
            onClick={() => setShowBuyerForm(true)}
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition mb-2"
          >
            {t('أنا مشتري', 'I\'m a Buyer')}
          </button>

          {!registeredBuyer ? (
            <p className="text-xs text-gray-500 text-center">
              {t('سجل لعرض رقم الهاتف', 'Register to view phone number')}
            </p>
          ) : (
            <div className="bg-green-50 rounded-lg p-3 flex items-center gap-3">
              <Phone className="w-5 h-5 text-green-600 flex-shrink-0" />
              <div>
                <p className="text-xs text-gray-600">{t('رقم البائع:', 'Seller Phone:')}</p>
                <p className="font-bold text-gray-800">{listing.sellerPhone}</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {showBuyerForm && (
        <BuyerRegistrationForm
          listingType={type}
          listingId={listing.id}
          listingTitle={title}
          onClose={() => setShowBuyerForm(false)}
          onRegister={(data) => {
            setRegisteredBuyer(data);
            setShowBuyerForm(false);
          }}
        />
      )}
    </>
  );
}
