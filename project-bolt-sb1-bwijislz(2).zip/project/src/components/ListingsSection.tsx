import { useState } from 'react';
import { Building2, Car } from 'lucide-react';
import { ListingCard } from './ListingCard';
import { useLanguage } from '../contexts/LanguageContext';
import { realEstateListings, carListings } from '../data/listings';

export function ListingsSection() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'real_estate' | 'car'>('real_estate');

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">
          {t('الإعلانات المتاحة', 'Available Listings')}
          <div className="w-20 h-1 bg-green-500 mx-auto mt-4 rounded"></div>
        </h2>

        <div className="flex justify-center mb-12">
          <div className="inline-flex rounded-lg border-2 border-gray-300 p-1">
            <button
              onClick={() => setActiveTab('real_estate')}
              className={`flex items-center gap-2 px-6 py-3 font-bold rounded-lg transition ${
                activeTab === 'real_estate'
                  ? 'bg-green-500 text-white'
                  : 'bg-white text-gray-800 hover:bg-gray-100'
              }`}
            >
              <Building2 className="w-5 h-5" />
              {t('العقارات', 'Real Estate')}
            </button>
            <button
              onClick={() => setActiveTab('car')}
              className={`flex items-center gap-2 px-6 py-3 font-bold rounded-lg transition ${
                activeTab === 'car'
                  ? 'bg-green-500 text-white'
                  : 'bg-white text-gray-800 hover:bg-gray-100'
              }`}
            >
              <Car className="w-5 h-5" />
              {t('السيارات', 'Cars')}
            </button>
          </div>
        </div>

        {activeTab === 'real_estate' && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <p className="text-gray-600">
                {t('عدد الإعلانات:', 'Number of listings:')} {realEstateListings.length}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {realEstateListings.map((property) => (
                <ListingCard
                  key={property.id}
                  listing={property}
                  type="real_estate"
                />
              ))}
            </div>
          </div>
        )}

        {activeTab === 'car' && (
          <div className="space-y-8">
            <div className="text-center mb-8">
              <p className="text-gray-600">
                {t('عدد الإعلانات:', 'Number of listings:')} {carListings.length}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {carListings.map((car) => (
                <ListingCard
                  key={car.id}
                  listing={car}
                  type="car"
                />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
