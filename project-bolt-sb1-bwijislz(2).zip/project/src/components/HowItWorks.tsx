import { Search, MousePointer, ShoppingCart, DollarSign } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function HowItWorks() {
  const { t } = useLanguage();

  const steps = [
    {
      icon: Search,
      titleAr: 'اكتشف العروض',
      titleEn: 'Discover Offers',
      descriptionAr: 'نبحث عن أفضل العروض والمنتجات لتوفير وقتك ومالك',
      descriptionEn: 'We search for the best offers and products to save your time and money'
    },
    {
      icon: MousePointer,
      titleAr: 'انقر على الرابط',
      titleEn: 'Click the Link',
      descriptionAr: 'انقر على رابط المنتج أو الخدمة التي تهمك',
      descriptionEn: 'Click on the link of the product or service that interests you'
    },
    {
      icon: ShoppingCart,
      titleAr: 'اشتر من الموقع',
      titleEn: 'Purchase from the Site',
      descriptionAr: 'أكمل عملية الشراء من موقع الشريك بسعر عادي',
      descriptionEn: 'Complete your purchase from the partner site at the normal price'
    },
    {
      icon: DollarSign,
      titleAr: 'نحصل على عمولة',
      titleEn: 'We Earn Commission',
      descriptionAr: 'بدون أي تكلفة إضافية عليك، نحصل على عمولة من الشريك',
      descriptionEn: 'At no extra cost to you, we earn a commission from the partner'
    }
  ];

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-16 text-gray-800">
          {t('كيف يعمل التسويق بالعمولة؟', 'How Does Affiliate Marketing Work?')}
          <div className="w-20 h-1 bg-green-500 mx-auto mt-4 rounded"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="text-center p-6">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6 hover:bg-green-100 transition">
                  <Icon className="w-10 h-10 text-green-600" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-800">
                  {t(step.titleAr, step.titleEn)}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {t(step.descriptionAr, step.descriptionEn)}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
