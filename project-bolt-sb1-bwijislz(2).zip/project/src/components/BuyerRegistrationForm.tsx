import { useState } from 'react';
import { X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface BuyerRegistrationFormProps {
  listingType: 'real_estate' | 'car';
  listingId: string;
  listingTitle: string;
  onClose: () => void;
  onRegister: (data: { name: string; email: string; phone: string }) => void;
}

export function BuyerRegistrationForm({
  listingType,
  listingTitle,
  onClose,
  onRegister
}: BuyerRegistrationFormProps) {
  const { language, t } = useLanguage();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim() || !email.trim() || !phone.trim()) {
      setError(t('يرجى ملء جميع الحقول', 'Please fill all fields'));
      return;
    }

    if (!email.includes('@')) {
      setError(t('يرجى إدخال بريد إلكتروني صحيح', 'Please enter a valid email'));
      return;
    }

    setLoading(true);

    try {
      const successMessage = t(
        'تم تسجيلك بنجاح! يمكنك الآن رؤية رقم الهاتف',
        'You registered successfully! You can now see the phone number'
      );
      alert(successMessage);
      onRegister({ name, email, phone });
    } catch {
      setError(t('حدث خطأ ما', 'An error occurred'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full shadow-2xl">
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">{t('تسجيل المشتري', 'Buyer Registration')}</h2>
            <p className="text-green-100 text-sm mt-1">{listingTitle}</p>
          </div>
          <button
            onClick={onClose}
            className="hover:bg-white/20 p-2 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              {t('الاسم الكامل', 'Full Name')}
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t('أدخل اسمك', 'Enter your name')}
              className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:outline-none"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              {t('البريد الإلكتروني', 'Email')}
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t('أدخل بريدك الإلكتروني', 'Enter your email')}
              className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:outline-none"
              disabled={loading}
            />
          </div>

          <div>
            <label className="block text-gray-700 font-semibold mb-2">
              {t('رقم الهاتف', 'Phone Number')}
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder={t('أدخل رقم هاتفك', 'Enter your phone number')}
              className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:outline-none"
              disabled={loading}
            />
          </div>

          {error && (
            <div className="bg-red-50 border-2 border-red-200 rounded-lg p-3">
              <p className="text-red-700 text-sm">{error}</p>
            </div>
          )}

          <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-3">
            <p className="text-blue-800 text-xs leading-relaxed">
              {t(
                'بتسجيلك كمشتري، سيتمكن البائع من رؤية معلومات الاتصال الخاصة بك',
                'By registering as a buyer, the seller will be able to see your contact information'
              )}
            </p>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-400 text-white font-bold py-3 px-6 rounded-lg transition"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                {t('جاري التسجيل...', 'Registering...')}
              </span>
            ) : (
              t('تسجيل', 'Register')
            )}
          </button>

          <button
            type="button"
            onClick={onClose}
            disabled={loading}
            className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-6 rounded-lg transition"
          >
            {t('إلغاء', 'Cancel')}
          </button>
        </form>
      </div>
    </div>
  );
}
