import { useState } from 'react';
import { X, CheckCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface CommitmentAgreementProps {
  listingType: 'real_estate' | 'car';
  listingTitle: string;
  sellerEmail: string;
  sellerPhone: string;
  onSign: (agreed: boolean) => void;
  onClose: () => void;
}

export function CommitmentAgreement({
  listingType,
  listingTitle,
  sellerEmail,
  sellerPhone,
  onSign,
  onClose
}: CommitmentAgreementProps) {
  const { language, t } = useLanguage();
  const [agreed, setAgreed] = useState(false);

  const handleSign = () => {
    if (agreed) {
      onSign(true);
    }
  };

  const agreementContent = {
    title: t(
      'تعهد التسويق بالعمولة',
      'Commission Marketing Commitment Agreement'
    ),
    subtitle: t(
      'هذا التعهد بين البائع والمنصة والمشتري',
      'This agreement between the seller, platform, and buyer'
    ),
    sections: [
      {
        heading: t('1. تعريف المشاركات', '1. Definition of Parties'),
        content: t(
          'البائع: الشخص الذي يقوم بتسويق العقار أو السيارة',
          'Seller: The person marketing the real estate or car'
        )
      },
      {
        heading: t('2. نسبة العمولة', '2. Commission Rate'),
        content: t(
          'يوافق البائع على دفع 1% من قيمة البيع الكلية كعمولة للمنصة عند تمام البيع',
          'The seller agrees to pay 1% of the total sale value as a commission to the platform upon completion of the sale'
        )
      },
      {
        heading: t('3. شروط الدفع', '3. Payment Terms'),
        content: t(
          'يتم دفع العمولة خلال 7 أيام من تأكيد البيع',
          'Commission is due within 7 days of confirming the sale'
        )
      },
      {
        heading: t('4. مسؤوليات البائع', '4. Seller Responsibilities'),
        content: t(
          'البائع مسؤول عن دقة المعلومات ويتعهد بعدم الخداع',
          'Seller is responsible for accuracy of information and commits to no deception'
        )
      },
      {
        heading: t('5. مسؤوليات المشتري', '5. Buyer Responsibilities'),
        content: t(
          'المشتري يقبل بشروط الشراء والسعر المتفق عليه',
          'Buyer accepts the terms of purchase and agreed price'
        )
      },
      {
        heading: t('6. الإلزامية', '6. Binding Nature'),
        content: t(
          'هذا التعهد ملزم قانونياً لجميع الأطراف',
          'This commitment is legally binding for all parties'
        )
      }
    ]
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">{agreementContent.title}</h2>
            <p className="text-blue-100 mt-1">{agreementContent.subtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="hover:bg-white/20 p-2 rounded-lg transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8">
          <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 mb-6">
            <p className="text-gray-800 font-semibold">
              {t('الإعلان:', 'Listing:')} <span className="text-blue-600">{listingTitle}</span>
            </p>
            <p className="text-gray-700 text-sm mt-2">
              {t('البريد الإلكتروني:', 'Email:')} {sellerEmail}
            </p>
            <p className="text-gray-700 text-sm">
              {t('الهاتف:', 'Phone:')} {sellerPhone}
            </p>
          </div>

          <div className="space-y-4 mb-6 border-l-4 border-blue-600 pl-4">
            {agreementContent.sections.map((section, index) => (
              <div key={index}>
                <h3 className="font-bold text-gray-800 mb-2">{section.heading}</h3>
                <p className="text-gray-700 leading-relaxed">{section.content}</p>
              </div>
            ))}
          </div>

          <div className="bg-yellow-50 border-2 border-yellow-200 rounded-lg p-4 mb-6">
            <p className="text-yellow-800 text-sm font-semibold">
              {t(
                'بتوقيعك على هذا التعهد، أنت توافق على جميع الشروط والأحكام أعلاه',
                'By signing this agreement, you agree to all the terms and conditions above'
              )}
            </p>
          </div>

          <div className="flex items-center gap-3 mb-6">
            <input
              type="checkbox"
              id="agree"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="w-5 h-5 text-blue-600 rounded cursor-pointer"
            />
            <label htmlFor="agree" className="text-gray-800 font-semibold cursor-pointer">
              {t(
                'أوافق على جميع الشروط والأحكام أعلاه',
                'I agree to all the terms and conditions above'
              )}
            </label>
          </div>

          <div className="flex gap-4">
            <button
              onClick={handleSign}
              disabled={!agreed}
              className={`flex-1 font-bold py-3 px-6 rounded-lg transition flex items-center justify-center gap-2 ${
                agreed
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <CheckCircle className="w-5 h-5" />
              {t('وقعت على التعهد', 'Sign Agreement')}
            </button>
            <button
              onClick={onClose}
              className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-6 rounded-lg transition"
            >
              {t('إلغاء', 'Cancel')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
