import { Bed, Bath, Square, Car, ExternalLink } from 'lucide-react';
import { RealEstateProperty } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface RealEstateSectionProps {
  property: RealEstateProperty;
}

export function RealEstateSection({ property }: RealEstateSectionProps) {
  const { language, t } = useLanguage();

  const handleRedirect = () => {
    const message = t(
      'سيتم توجيهك الآن إلى موقع الشريك. شكرًا لاستخدامك رابطنا التابع!',
      'You will now be redirected to the partner site. Thank you for using our affiliate link!'
    );
    alert(message);
    window.open(property.affiliateUrl, '_blank');
  };

  return (
    <section className="bg-gray-100 py-16 my-16">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-800">
          {t('عقارات مميزة', 'Featured Real Estate')}
          <div className="w-20 h-1 bg-green-500 mx-auto mt-4 rounded"></div>
        </h2>

        <div className="bg-white rounded-xl overflow-hidden shadow-xl flex flex-col lg:flex-row">
          <div
            className="lg:w-1/2 min-h-[400px] bg-cover bg-center"
            style={{ backgroundImage: `url(${property.imageUrl})` }}
          />

          <div className="lg:w-1/2 p-8 lg:p-12 flex flex-col justify-center">
            <h3 className="text-3xl font-bold mb-6 text-gray-800">
              {language === 'ar' ? property.titleAr : property.titleEn}
            </h3>

            <p className="text-gray-600 mb-6 text-lg leading-relaxed">
              {language === 'ar' ? property.descriptionAr : property.descriptionEn}
            </p>

            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-lg">
                <Bed className="w-6 h-6 text-green-500" />
                <span>
                  {property.bedrooms} {t('غرف نوم', 'Bedrooms')}
                </span>
              </li>
              <li className="flex items-center gap-3 text-lg">
                <Bath className="w-6 h-6 text-green-500" />
                <span>
                  {property.bathrooms} {t('حمامات', 'Bathrooms')}
                </span>
              </li>
              <li className="flex items-center gap-3 text-lg">
                <Square className="w-6 h-6 text-green-500" />
                <span>
                  {property.area} {t('م²', 'm²')}
                </span>
              </li>
              <li className="flex items-center gap-3 text-lg">
                <Car className="w-6 h-6 text-green-500" />
                <span>
                  {t('جراج لـ', 'Garage for')} {property.parking} {t('سيارات', 'cars')}
                </span>
              </li>
            </ul>

            <div className="text-4xl font-bold text-red-600 mb-6">
              {property.price.toLocaleString()} {t('ريال', 'SAR')}
            </div>

            <button
              onClick={handleRedirect}
              className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-6 rounded-lg transition flex items-center justify-center gap-2 text-lg"
            >
              {t('انتقل لموقع العقار', 'Go to Property Site')}
              <ExternalLink className="w-5 h-5" />
            </button>

            <p className="text-sm text-gray-500 text-center mt-4">
              {t('سيتم توجيهك إلى موقع شركة العقار', 'You will be redirected to the real estate company')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
