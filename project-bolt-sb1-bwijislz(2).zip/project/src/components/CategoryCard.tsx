import { useState } from 'react';
import { ShoppingBag } from 'lucide-react';
import { Category } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { ProductSelector } from './ProductSelector';

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  const { language, t } = useLanguage();
  const [showProductSelector, setShowProductSelector] = useState(false);

  return (
    <>
      <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
        <div className="relative">
          <span className="absolute top-3 left-3 bg-red-600 text-white px-3 py-1 rounded text-sm font-bold z-10">
            {t('عمولة', 'Commission')}
          </span>
          <img
            src={category.imageUrl}
            alt={language === 'ar' ? category.titleAr : category.titleEn}
            className="w-full h-52 object-cover"
          />
        </div>

        <div className="p-6">
          <h3 className="text-2xl font-bold mb-3 text-gray-800">
            {language === 'ar' ? category.titleAr : category.titleEn}
          </h3>
          <p className="text-gray-600 mb-6 leading-relaxed">
            {language === 'ar' ? category.descriptionAr : category.descriptionEn}
          </p>

          <button
            onClick={() => setShowProductSelector(true)}
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition flex items-center justify-center gap-2"
          >
            <ShoppingBag className="w-5 h-5" />
            {t('اختر منتجك', 'Choose Your Product')}
          </button>

          <p className="text-sm text-gray-500 text-center mt-3">
            {t('اختر منتجاً من القسم للشراء', 'Choose a product from the category to purchase')}
          </p>
        </div>
      </div>

      {showProductSelector && (
        <ProductSelector
          categoryId={category.id}
          categoryTitle={language === 'ar' ? category.titleAr : category.titleEn}
          onClose={() => setShowProductSelector(false)}
        />
      )}
    </>
  );
}
