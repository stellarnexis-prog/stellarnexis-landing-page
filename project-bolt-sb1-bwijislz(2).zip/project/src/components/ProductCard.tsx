import { ExternalLink } from 'lucide-react';
import { Product } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { language, t } = useLanguage();

  const handleBuyClick = () => {
    const message = t(
      'سيتم توجيهك الآن إلى موقع الشريك. شكرًا لاستخدامك رابطنا التابع!',
      'You will now be redirected to the partner site. Thank you for using our affiliate link!'
    );
    alert(message);
    window.open(product.affiliateUrl, '_blank');
  };

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300">
      <div className="relative h-48 overflow-hidden">
        <img
          src={product.imageUrl}
          alt={language === 'ar' ? product.nameAr : product.nameEn}
          className="w-full h-full object-cover hover:scale-105 transition duration-300"
        />
        <span className="absolute top-3 left-3 bg-red-600 text-white px-3 py-1 rounded text-xs font-bold">
          {t('عمولة', 'Commission')}
        </span>
      </div>

      <div className="p-4">
        <h3 className="text-lg font-bold text-gray-800 mb-2 line-clamp-2">
          {language === 'ar' ? product.nameAr : product.nameEn}
        </h3>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2 leading-relaxed h-10">
          {language === 'ar' ? product.descriptionAr : product.descriptionEn}
        </p>

        <div className="mb-3">
          <div className="text-2xl font-bold text-green-600 mb-1">
            {product.price} {t('ريال', 'SAR')}
          </div>
        </div>

        <button
          onClick={handleBuyClick}
          className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition flex items-center justify-center gap-2"
        >
          {t('اشتر الآن', 'Buy Now')}
          <ExternalLink className="w-4 h-4" />
        </button>

        <p className="text-xs text-gray-500 text-center mt-2">
          {t('سيتم توجيهك للموقع الخارجي', 'You will be redirected to external site')}
        </p>
      </div>
    </div>
  );
}
