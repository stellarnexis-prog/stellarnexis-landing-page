import { Search, DollarSign } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function Header() {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="bg-green-600 text-white sticky top-0 z-50 shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <DollarSign className="w-8 h-8" />
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">
                {t('دليلك للتسوق', 'Your Shopping Guide')}
              </h1>
              <span className="bg-red-600 text-white px-3 py-1 rounded-full text-xs font-semibold">
                {t('تسويق بالعمولة', 'Affiliate')}
              </span>
            </div>
          </div>

          <nav className="hidden md:block">
            <ul className="flex gap-4">
              <li>
                <a href="#" className="hover:bg-white/20 px-3 py-2 rounded-lg transition">
                  {t('الرئيسية', 'Home')}
                </a>
              </li>
              <li>
                <a href="#categories" className="hover:bg-white/20 px-3 py-2 rounded-lg transition">
                  {t('أفضل العروض', 'Best Deals')}
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:bg-white/20 px-3 py-2 rounded-lg transition">
                  {t('كيف يعمل', 'How It Works')}
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:bg-white/20 px-3 py-2 rounded-lg transition">
                  {t('اتصل بنا', 'Contact')}
                </a>
              </li>
            </ul>
          </nav>

          <div className="flex items-center gap-4">
            <div className="flex gap-2">
              <button
                onClick={() => setLanguage('ar')}
                className={`px-3 py-1 rounded-lg transition ${
                  language === 'ar' ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                العربية
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-lg transition ${
                  language === 'en' ? 'bg-white/20' : 'hover:bg-white/10'
                }`}
              >
                English
              </button>
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder={t('ابحث عن منتج...', 'Search for a product...')}
                className="pl-4 pr-10 py-2 rounded-full text-gray-800 w-48 focus:outline-none focus:ring-2 focus:ring-green-300"
              />
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
