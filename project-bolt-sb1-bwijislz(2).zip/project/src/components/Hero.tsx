import { Info } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function Hero() {
  const { t } = useLanguage();

  const scrollToCategories = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('categories');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="relative bg-gradient-to-b from-gray-900 to-gray-800 text-white py-24 mb-16">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-40"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80')"
        }}
      />

      <div className="container mx-auto px-4 relative z-10 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
          {t('وفر أموالك مع أفضل العروض', 'Save Money With The Best Deals')}
        </h1>

        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
          {t(
            'نحن نبحث عن أفضل العروض ونوصي بها، وعند الشراء من خلال روابطنا قد نحصل على عمولة بدون أي تكلفة إضافية عليك',
            'We find the best deals and recommend them, and when you purchase through our links we may earn a commission at no extra cost to you'
          )}
        </p>

        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-6 max-w-3xl mx-auto mb-8">
          <p className="flex items-center justify-center gap-2 text-lg">
            <Info className="w-5 h-5" />
            <strong>{t('ملاحظة:', 'Note:')}</strong>
            {t(
              ' نحن شركاء تسويق مع هذه المواقع. عند النقر على الروابط والشراء، قد نكسب عمولة بدون أي تكلفة إضافية عليك.',
              ' We are marketing partners with these sites. When you click links and make purchases, we may earn a commission at no extra cost to you.'
            )}
          </p>
        </div>

        <a
          href="#categories"
          onClick={scrollToCategories}
          className="inline-block bg-red-600 hover:bg-red-700 text-white font-bold text-lg px-8 py-4 rounded-full transition transform hover:-translate-y-1 shadow-lg"
        >
          {t('استعرض العروض', 'Browse Offers')}
        </a>
      </div>
    </section>
  );
}
