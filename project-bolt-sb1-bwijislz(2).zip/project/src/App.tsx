import { LanguageProvider } from './contexts/LanguageContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoryCard } from './components/CategoryCard';
import { RealEstateSection } from './components/RealEstateSection';
import { HowItWorks } from './components/HowItWorks';
import { ListingsSection } from './components/ListingsSection';
import { ProductCard } from './components/ProductCard';
import { Footer } from './components/Footer';
import { categories, featuredProperty } from './data/categories';
import { products } from './data/products';
import { useLanguage } from './contexts/LanguageContext';

function AppContent() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Hero />

      <section id="categories" className="container mx-auto px-4 py-12">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-800">
          {t('أفضل العروض حسب الأقسام', 'Best Offers By Category')}
          <div className="w-20 h-1 bg-green-500 mx-auto mt-4 rounded"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </section>

      <ListingsSection />

      <section id="products" className="container mx-auto px-4 py-20">
        <h2 className="text-4xl font-bold text-center mb-12 text-gray-800">
          {t('منتجات متنوعة', 'Various Products')}
          <div className="w-20 h-1 bg-green-500 mx-auto mt-4 rounded"></div>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.slice(0, 12).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {products.length > 12 && (
          <div className="text-center mt-8">
            <p className="text-gray-600">
              {t('عدد المنتجات:', 'Number of products:')} {products.length}
            </p>
          </div>
        )}
      </section>

      <RealEstateSection property={featuredProperty} />
      <HowItWorks />
      <Footer />
    </div>
  );
}

function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

export default App;
