export type Language = 'ar' | 'en';

export interface Category {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  imageUrl: string;
  affiliateUrl: string;
}

export interface Product {
  id: string;
  categoryId: string;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  imageUrl: string;
  price: number;
  affiliateUrl: string;
}

export interface RealEstateListing {
  id: string;
  sellerId: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  imageUrls: string[];
  price: number;
  bedrooms: number;
  bathrooms: number;
  area: number;
  sellerPhone: string;
  commitmentSigned: boolean;
  createdAt: string;
}

export interface CarListing {
  id: string;
  sellerId: string;
  brand: string;
  model: string;
  year: number;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  imageUrls: string[];
  price: number;
  mileage: number;
  fuelType: string;
  transmission: string;
  sellerPhone: string;
  commitmentSigned: boolean;
  createdAt: string;
}

export interface BuyerRegistration {
  id: string;
  listingType: 'real_estate' | 'car';
  listingId: string;
  buyerEmail: string;
  buyerPhone: string;
  buyerName: string;
  createdAt: string;
}

export interface CommitmentAgreement {
  id: string;
  listingType: 'real_estate' | 'car';
  listingId: string;
  sellerId: string;
  sellerPhone: string;
  sellerEmail: string;
  commissionPercentage: number;
  agreedAt: string;
  signed: boolean;
}

export interface RealEstateProperty {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  imageUrl: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  parking: number;
  price: number;
  affiliateUrl: string;
}
