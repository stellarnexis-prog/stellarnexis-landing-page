import { RealEstateListing, CarListing } from '../types';

export const realEstateListings: RealEstateListing[] = [
  {
    id: 're-1',
    sellerId: 'seller-1',
    titleAr: 'فيلا فاخرة في حي الرمال',
    titleEn: 'Luxury Villa in Al-Rimal District',
    descriptionAr: 'فيلا حديثة بتصميم عصري مع إطلالة رائعة ومساحات خضراء',
    descriptionEn: 'Modern villa with contemporary design, stunning views and green spaces',
    imageUrls: [
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 4500000,
    bedrooms: 5,
    bathrooms: 4,
    area: 450,
    sellerPhone: '+966501234567',
    commitmentSigned: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 're-2',
    sellerId: 'seller-2',
    titleAr: 'شقة حديثة في وسط المدينة',
    titleEn: 'Modern Apartment in City Center',
    descriptionAr: 'شقة فاخرة مع إطلالة على المدينة وقرب من جميع الخدمات',
    descriptionEn: 'Luxury apartment with city view close to all amenities',
    imageUrls: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 1800000,
    bedrooms: 3,
    bathrooms: 2,
    area: 150,
    sellerPhone: '+966501234568',
    commitmentSigned: false,
    createdAt: new Date().toISOString()
  },
  {
    id: 're-3',
    sellerId: 'seller-3',
    titleAr: 'أرض سكنية في حي النخيل',
    titleEn: 'Residential Land in Al-Nakheel District',
    descriptionAr: 'قطعة أرض واسعة صالحة للبناء في موقع استراتيجي',
    descriptionEn: 'Large land plot suitable for construction in strategic location',
    imageUrls: [
      'https://images.unsplash.com/photo-1500382017468-f049863aae22?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 1200000,
    bedrooms: 0,
    bathrooms: 0,
    area: 800,
    sellerPhone: '+966501234569',
    commitmentSigned: true,
    createdAt: new Date().toISOString()
  }
];

export const carListings: CarListing[] = [
  {
    id: 'car-1',
    sellerId: 'seller-1',
    brand: 'BMW',
    model: 'X7',
    year: 2023,
    titleAr: 'سيارة BMW X7 2023 جديدة',
    titleEn: 'New BMW X7 2023',
    descriptionAr: 'سيارة فاخرة بمحرك قوي وتجهيزات متقدمة',
    descriptionEn: 'Luxury car with powerful engine and advanced features',
    imageUrls: [
      'https://images.unsplash.com/photo-1552883657-23ac6c6360a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1541899481282-d53bffe3c346?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 420000,
    mileage: 5000,
    fuelType: 'petrol',
    transmission: 'automatic',
    sellerPhone: '+966501234567',
    commitmentSigned: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'car-2',
    sellerId: 'seller-2',
    brand: 'Toyota',
    model: 'Camry',
    year: 2022,
    titleAr: 'تويوتا كامري 2022',
    titleEn: 'Toyota Camry 2022',
    descriptionAr: 'سيارة موثوقة واقتصادية بحالة ممتازة',
    descriptionEn: 'Reliable and economical car in excellent condition',
    imageUrls: [
      'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 120000,
    mileage: 45000,
    fuelType: 'petrol',
    transmission: 'automatic',
    sellerPhone: '+966501234568',
    commitmentSigned: false,
    createdAt: new Date().toISOString()
  },
  {
    id: 'car-3',
    sellerId: 'seller-3',
    brand: 'Mercedes',
    model: 'C-Class',
    year: 2023,
    titleAr: 'مرسيدس C-Class 2023',
    titleEn: 'Mercedes C-Class 2023',
    descriptionAr: 'سيارة فاخرة بأحدث التقنيات والتجهيزات',
    descriptionEn: 'Luxury car with latest technology and features',
    imageUrls: [
      'https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 380000,
    mileage: 12000,
    fuelType: 'petrol',
    transmission: 'automatic',
    sellerPhone: '+966501234569',
    commitmentSigned: true,
    createdAt: new Date().toISOString()
  },
  {
    id: 'car-4',
    sellerId: 'seller-4',
    brand: 'Nissan',
    model: 'Qashqai',
    year: 2021,
    titleAr: 'نيسان قاشقاي 2021',
    titleEn: 'Nissan Qashqai 2021',
    descriptionAr: 'سيارة رياضية عملية وآمنة',
    descriptionEn: 'Practical and safe sport utility vehicle',
    imageUrls: [
      'https://images.unsplash.com/photo-1559416523-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    price: 95000,
    mileage: 62000,
    fuelType: 'petrol',
    transmission: 'automatic',
    sellerPhone: '+966501234570',
    commitmentSigned: false,
    createdAt: new Date().toISOString()
  }
];
