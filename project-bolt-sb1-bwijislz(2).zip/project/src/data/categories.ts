import { Category, RealEstateProperty } from '../types';

export const categories: Category[] = [
  {
    id: 'fashion',
    titleAr: 'ملابس',
    titleEn: 'Clothes',
    descriptionAr: 'أحدث صيحات الموضة بأسعار مميزة من أفضل المتاجر',
    descriptionEn: 'Latest fashion trends at special prices from the best stores',
    imageUrl: 'https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1171&q=80',
    affiliateUrl: 'https://example-fashion.com'
  },
  {
    id: 'furniture',
    titleAr: 'أثاث',
    titleEn: 'Furniture',
    descriptionAr: 'أثاث منزلي ومكتبي بجودة عالية وتوصيل مجاني',
    descriptionEn: 'High quality home and office furniture with free delivery',
    imageUrl: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1158&q=80',
    affiliateUrl: 'https://example-furniture.com'
  },
  {
    id: 'electronics',
    titleAr: 'أجهزة',
    titleEn: 'Devices',
    descriptionAr: 'أحدث الأجهزة الإلكترونية والهواتف بأسعار منافسة',
    descriptionEn: 'Latest electronic devices and phones at competitive prices',
    imageUrl: 'https://images.unsplash.com/photo-1468436139062-f60a71c5c892?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
    affiliateUrl: 'https://example-electronics.com'
  },
  {
    id: 'services',
    titleAr: 'خدمات واشتراكات',
    titleEn: 'Services & Subscriptions',
    descriptionAr: 'خدمات واشتراكات متنوعة بخصومات حصرية من خلال روابطنا',
    descriptionEn: 'Various services and subscriptions with exclusive discounts through our links',
    imageUrl: 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
    affiliateUrl: 'https://example-services.com'
  },
  {
    id: 'beauty',
    titleAr: 'الجمال والعناية',
    titleEn: 'Beauty & Care',
    descriptionAr: 'شعر مستعار ومنتجات عناية بشرة بجودة عالية',
    descriptionEn: 'Wigs and high quality skincare products',
    imageUrl: 'https://images.unsplash.com/photo-1596462502278-af407713fc22?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80',
    affiliateUrl: 'https://example-beauty.com'
  },
  {
    id: 'health',
    titleAr: 'الصحة والتغذية',
    titleEn: 'Health & Nutrition',
    descriptionAr: 'مكملات غذائية وفيتامينات من أفضل الماركات العالمية',
    descriptionEn: 'Supplements and vitamins from best international brands',
    imageUrl: 'https://images.unsplash.com/photo-1576091160550-112173f31c77?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80',
    affiliateUrl: 'https://example-health.com'
  },
  {
    id: 'pets',
    titleAr: 'حيوانات',
    titleEn: 'Animals',
    descriptionAr: 'مستلزمات الحيوانات الأليفة والطعام بأسعار منافسة',
    descriptionEn: 'Pet supplies and food at competitive prices',
    imageUrl: 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1158&q=80',
    affiliateUrl: 'https://example-pets.com'
  },
  {
    id: 'watches',
    titleAr: 'الساعات',
    titleEn: 'Watches',
    descriptionAr: 'ساعات فاخرة وكلاسيكية من أفضل الماركات العالمية',
    descriptionEn: 'Luxury and classic watches from the best international brands',
    imageUrl: 'https://images.unsplash.com/photo-1523170335258-f5ed11844a49?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80',
    affiliateUrl: 'https://example-watches.com'
  }
];

export const featuredProperty: RealEstateProperty = {
  id: 'villa-1',
  titleAr: 'فيلا فاخرة في حي الرمال',
  titleEn: 'Luxury Villa in Al-Rimal District',
  descriptionAr: 'فيلا حديثة بتصميم عصري مع إطلالة رائعة ومساحات خضراء',
  descriptionEn: 'Modern villa with contemporary design, stunning views and green spaces',
  imageUrl: 'https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80',
  bedrooms: 5,
  bathrooms: 4,
  area: 450,
  parking: 3,
  price: 4500000,
  affiliateUrl: 'https://example-realestate.com'
};
