/*
  # Create real estate and car listings with commitment agreements

  1. New Tables
    - `real_estate_listings`
      - `id` (uuid, primary key)
      - `seller_id` (uuid, seller user id)
      - `title_ar` (text, listing title in Arabic)
      - `title_en` (text, listing title in English)
      - `description_ar` (text)
      - `description_en` (text)
      - `image_urls` (text[], array of image URLs)
      - `price` (numeric)
      - `bedrooms` (integer)
      - `bathrooms` (integer)
      - `area` (numeric, in square meters)
      - `seller_phone` (text, hidden until buyer registers)
      - `commitment_signed` (boolean, whether seller signed agreement)
      - `created_at` (timestamp)

    - `car_listings`
      - `id` (uuid, primary key)
      - `seller_id` (uuid, seller user id)
      - `brand` (text, car brand)
      - `model` (text, car model)
      - `year` (integer)
      - `title_ar` (text)
      - `title_en` (text)
      - `description_ar` (text)
      - `description_en` (text)
      - `image_urls` (text[])
      - `price` (numeric)
      - `mileage` (integer, in km)
      - `fuel_type` (text, petrol/diesel/electric/hybrid)
      - `transmission` (text, manual/automatic)
      - `seller_phone` (text)
      - `commitment_signed` (boolean)
      - `created_at` (timestamp)

    - `buyer_registrations`
      - `id` (uuid, primary key)
      - `listing_type` (text, 'real_estate' or 'car')
      - `listing_id` (uuid)
      - `buyer_email` (text)
      - `buyer_phone` (text)
      - `buyer_name` (text)
      - `created_at` (timestamp)

    - `commitment_agreements`
      - `id` (uuid, primary key)
      - `listing_type` (text)
      - `listing_id` (uuid)
      - `seller_id` (uuid)
      - `seller_phone` (text)
      - `seller_email` (text)
      - `commission_percentage` (numeric, default 1)
      - `agreed_at` (timestamp)
      - `signed` (boolean)

  2. Security
    - Enable RLS on all tables
    - Listings visible to public (read-only)
    - Seller can update own listings
    - Buyer registrations are insertable by public
    - Agreements are viewable/insertable by authenticated sellers
*/

CREATE TABLE IF NOT EXISTS real_estate_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid,
  title_ar text NOT NULL,
  title_en text NOT NULL,
  description_ar text,
  description_en text,
  image_urls text[] DEFAULT '{}',
  price numeric NOT NULL,
  bedrooms integer,
  bathrooms integer,
  area numeric,
  seller_phone text NOT NULL,
  commitment_signed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS car_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid,
  brand text NOT NULL,
  model text NOT NULL,
  year integer,
  title_ar text NOT NULL,
  title_en text NOT NULL,
  description_ar text,
  description_en text,
  image_urls text[] DEFAULT '{}',
  price numeric NOT NULL,
  mileage integer,
  fuel_type text,
  transmission text,
  seller_phone text NOT NULL,
  commitment_signed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS buyer_registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_type text NOT NULL,
  listing_id uuid NOT NULL,
  buyer_email text NOT NULL,
  buyer_phone text NOT NULL,
  buyer_name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS commitment_agreements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_type text NOT NULL,
  listing_id uuid NOT NULL,
  seller_id uuid,
  seller_phone text NOT NULL,
  seller_email text,
  commission_percentage numeric DEFAULT 1,
  agreed_at timestamptz DEFAULT now(),
  signed boolean DEFAULT false
);

ALTER TABLE real_estate_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE car_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyer_registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE commitment_agreements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Real estate listings are publicly readable"
  ON real_estate_listings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Car listings are publicly readable"
  ON car_listings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Buyer registrations are insertable by public"
  ON buyer_registrations FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Buyer can view own registrations"
  ON buyer_registrations FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Commitment agreements are insertable by public"
  ON commitment_agreements FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Commitment agreements are readable"
  ON commitment_agreements FOR SELECT
  TO public
  USING (true);
