/*
  # Create products table

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `category_id` (text, identifies product category)
      - `name_ar` (text, product name in Arabic)
      - `name_en` (text, product name in English)
      - `description_ar` (text, product description in Arabic)
      - `description_en` (text, product description in English)
      - `image_url` (text, product image)
      - `price` (numeric, product price)
      - `affiliate_url` (text, affiliate redirect link)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `products` table
    - Add policy for public read access (affiliate products should be publicly visible)
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id text NOT NULL,
  name_ar text NOT NULL,
  name_en text NOT NULL,
  description_ar text,
  description_en text,
  image_url text,
  price numeric,
  affiliate_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Products are publicly readable"
  ON products
  FOR SELECT
  TO public
  USING (true);
