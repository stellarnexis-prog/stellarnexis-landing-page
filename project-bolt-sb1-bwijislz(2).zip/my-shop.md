/*
  هذا ملف ZIP لمشروع React + TypeScript + Tailwind متكامل جاهز للرفع
  - كل المنتجات روابط بالعمولة
  - العقارات والسيارات تعرض بيانات البائع
  - اللغة الإنجليزية رئيسية
*/

// 1. package.json
{
  "name": "my-shop",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.278.0"
  },
  "devDependencies": {
    "@types/react": "^18.0.28",
    "@types/react-dom": "^18.0.11",
    "typescript": "^5.2.2",
    "vite": "^5.3.0",
    "tailwindcss": "^3.3.4",
    "postcss": "^8.4.30",
    "autoprefixer": "^10.4.14"
  }
}

// 2. tsconfig.json
{
  "compilerOptions": {
    "target": "ESNext",
    "useDefineForClassFields": true,
    "lib": ["DOM", "DOM.Iterable", "ESNext"],
    "allowJs": false,
    "skipLibCheck": true,
    "esModuleInterop": false,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "module": "ESNext",
    "moduleResolution": "Node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx"
  },
  "include": ["src"]
}

// 3. vite.config.ts
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()]
});

// 4. tailwind.config.js
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {} },
  plugins: []
};

// 5. postcss.config.js
module.exports = { plugins: { tailwindcss: {}, autoprefixer: {} } };

// 6. index.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Your Shopping Guide</title>
  </head>
  <body class="bg-gray-50">
    <div id="root"></div>
    <script type="module" src="src/main.tsx"></script>
  </body>
</html>

// 7. src/main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';
ReactDOM.createRoot(document.getElementById('root')!).render(<App />);

// 8. src/App.tsx
import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ListingsSection } from './components/ListingsSection';
import { LanguageProvider } from './contexts/LanguageContext';
export default function App() {
  return (
    <LanguageProvider>
      <Header />
      <Hero />
      <ListingsSection />
    </LanguageProvider>
  );
}

// باقي الملفات: components, contexts, types, data ستكون بنفس الكود الذي أرسلته سابقاً مع اللغة الإنجليزية وروابط المنتجات بالعمولة.
// عند إنشاء المشروع في جهازك، انسخ هذه الملفات وقم بضغط المجلد 'my-shop' كملف ZIP للرفع مباشرة.

